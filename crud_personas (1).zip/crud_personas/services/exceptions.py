class DniDuplicadoError(Exception):
    """Ya existe una persona con ese DNI."""


class PersonaNoEncontradaError(Exception):
    """No existe una persona con ese DNI."""
