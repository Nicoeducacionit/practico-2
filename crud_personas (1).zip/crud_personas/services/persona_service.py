from models.persona import Persona
from services.exceptions import DniDuplicadoError, PersonaNoEncontradaError


class PersonaService:
    """Reglas de negocio que coordinan varias llamadas al modelo y al repositorio."""

    def __init__(self, repositorio):
        self.repositorio = repositorio

    def listar(self):
        return self.repositorio.buscar_todas()

    def obtener(self, dni):
        persona = self.repositorio.buscar_por_dni(dni)
        if persona is None:
            raise PersonaNoEncontradaError(f"No existe una persona con DNI {dni}")
        return persona

    def crear(self, datos):
        persona = Persona.from_dict(datos)  # el modelo valida sus propios datos
        # Regla del servicio: el documento no se puede repetir
        if self.repositorio.buscar_por_dni(persona.dni) is not None:
            raise DniDuplicadoError(f"Ya existe una persona con DNI {persona.dni}")
        self.repositorio.guardar(persona)
        return persona
