import sqlite3

from models.persona import Persona


class PersonaRepository:
    """Persistencia en SQLite. Solo guarda y busca: sin reglas de negocio."""

    def __init__(self, db_path="personas.db"):
        self.db_path = db_path
        self._crear_tabla()

    def _conectar(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _crear_tabla(self):
        with self._conectar() as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS personas (
                       dni    INTEGER PRIMARY KEY,
                       nombre TEXT NOT NULL
                   )"""
            )

    @staticmethod
    def _a_persona(fila):
        return Persona(fila["dni"], fila["nombre"])

    def guardar(self, persona):
        with self._conectar() as conn:
            conn.execute(
                "INSERT INTO personas (dni, nombre) VALUES (?, ?)",
                (persona.dni, persona.nombre),
            )

    def buscar_todas(self):
        with self._conectar() as conn:
            filas = conn.execute("SELECT * FROM personas ORDER BY dni").fetchall()
        return [self._a_persona(f) for f in filas]

    def buscar_por_dni(self, dni):
        with self._conectar() as conn:
            fila = conn.execute("SELECT * FROM personas WHERE dni = ?", (dni,)).fetchone()
        return self._a_persona(fila) if fila else None
