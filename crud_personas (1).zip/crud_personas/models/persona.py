class Persona:
    """Clase principal del dominio.

    Reglas de negocio (validaciones que mantienen el objeto consistente
    durante todo su ciclo de vida):
      - El DNI debe ser un entero positivo.
      - El nombre empieza con mayúscula, el resto va en minúscula y
        no puede superar los 30 caracteres.

    El modelo NUNCA accede al repositorio.
    """

    LARGO_MAXIMO_NOMBRE = 30

    def __init__(self, dni, nombre):
        self.dni = dni
        self.nombre = nombre

    # --- dni --------------------------------------------------------------
    @property
    def dni(self):
        return self._dni

    @dni.setter
    def dni(self, valor):
        if isinstance(valor, bool) or not isinstance(valor, int) or valor <= 0:
            raise ValueError("El DNI debe ser un número entero positivo")
        self._dni = valor

    # --- nombre -----------------------------------------------------------
    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, valor):
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError("El nombre es obligatorio")
        valor = valor.strip()
        if len(valor) > self.LARGO_MAXIMO_NOMBRE:
            raise ValueError(
                f"El nombre no puede tener más de {self.LARGO_MAXIMO_NOMBRE} caracteres"
            )
        if valor != valor[0].upper() + valor[1:].lower():
            raise ValueError(
                "El nombre debe comenzar con mayúscula y el resto en minúscula"
            )
        self._nombre = valor

    # --- conversión -------------------------------------------------------
    def to_dict(self):
        return {"dni": self.dni, "nombre": self.nombre}

    @classmethod
    def from_dict(cls, datos):
        return cls(datos.get("dni"), datos.get("nombre"))
