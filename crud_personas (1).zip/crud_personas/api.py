from flask import Flask, jsonify, request

from repositories.persona_repository import PersonaRepository
from services.exceptions import DniDuplicadoError, PersonaNoEncontradaError
from services.persona_service import PersonaService


def create_app(db_path="personas.db"):
    app = Flask(__name__)
    servicio = PersonaService(PersonaRepository(db_path))

    @app.get("/personas")
    def listar():
        return jsonify([p.to_dict() for p in servicio.listar()])

    @app.get("/personas/<int:dni>")
    def obtener(dni):
        return jsonify(servicio.obtener(dni).to_dict())

    @app.post("/personas")
    def crear():
        persona = servicio.crear(request.get_json(silent=True) or {})
        return jsonify(persona.to_dict()), 201

    # Traducimos las excepciones de dominio a códigos HTTP
    @app.errorhandler(ValueError)
    def error_validacion(e):
        return jsonify({"error": str(e)}), 400

    @app.errorhandler(PersonaNoEncontradaError)
    def error_no_encontrada(e):
        return jsonify({"error": str(e)}), 404

    @app.errorhandler(DniDuplicadoError)
    def error_duplicado(e):
        return jsonify({"error": str(e)}), 409

    return app


if __name__ == "__main__":
    create_app().run(debug=True)
